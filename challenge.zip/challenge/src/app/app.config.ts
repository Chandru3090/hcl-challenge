export const CONFIG = {
    baseURL: 'http://www.datasciencetoolkit.org/',
    getCities: 'maps/api/geocode/json'
}
