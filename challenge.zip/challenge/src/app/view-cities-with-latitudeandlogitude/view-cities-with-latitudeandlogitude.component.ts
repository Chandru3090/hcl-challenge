import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-cities-with-latitudeandlogitude',
  templateUrl: './view-cities-with-latitudeandlogitude.component.html',
  styleUrls: ['./view-cities-with-latitudeandlogitude.component.css']
})
export class ViewCitiesWithLatitudeandlogitudeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
